using BeltExam.Models;

namespace BeltExam.ViewModels;

public class HomePageViewModel
{
    public User? User { get; set; }
    public LoginUser? LoginUser { get; set; }
}
