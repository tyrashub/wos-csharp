using SoloProject.Models;

namespace SoloProject.ViewModels;

public class IndexPageViewModel
{
    public User? User { get; set; }
    public LoginUser? LoginUser { get; set; }
}
